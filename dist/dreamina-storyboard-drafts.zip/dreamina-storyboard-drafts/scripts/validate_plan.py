"""Read-only validation of a draft plan; never invokes Dreamina or networking."""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

NODE = re.compile(r"node_[0-9a-hjkmnp-tv-z]{10}\Z")
UUID = re.compile(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z")
REF = re.compile(r"\{\{(node:[^{}]+)\}\}")

def require(condition, message):
    if not condition:
        raise ValueError(message)

def validate(plan):
    require(isinstance(plan, dict), 'plan must be an object')
    require(plan.get('generate') is False, 'generate must explicitly be false')
    require(plan.get('projectConfirmed') is True, 'project must be confirmed')
    require(UUID.fullmatch(str(plan.get('projectId', ''))), 'invalid projectId')
    drama, episode = plan.get('drama'), plan.get('episode')
    require(isinstance(drama, str) and drama.strip() == drama and drama and '\n' not in drama, 'invalid drama')
    require(isinstance(episode, str) and episode and not any(c.isspace() for c in episode), 'episode must be nonempty text')
    source = plan.get('promptSource', {})
    require(source.get('mode') in {'model', 'copy', 'file'}, 'invalid prompt source')
    if source['mode'] == 'file':
        path = Path(source.get('path', ''))
        require(path.is_absolute() and path.is_file(), 'prompt source file unavailable')
        require(source.get('kind') in {'prompts', 'guidance'}, 'file kind must be prompts or guidance')
        require(hashlib.sha256(path.read_bytes()).hexdigest() == source.get('sha256'), 'prompt source file changed')
    settings = plan.get('settings', {})
    for key in ('ratio', 'model', 'resolution'):
        require(isinstance(settings.get(key), str) and settings[key].strip(), f'missing {key}')
    require(re.fullmatch(r'\d+:\d+', settings['ratio']), 'invalid ratio syntax')
    require(all(int(v) > 0 for v in settings['ratio'].split(':')), 'ratio must be positive')
    shots = plan.get('shots')
    require(isinstance(shots, list) and shots, 'shots must be nonempty')
    ids, numbers = set(), set()
    for shot in shots:
        require(isinstance(shot, dict), 'shot must be an object')
        number, node = shot.get('shot'), shot.get('nodeId')
        require(isinstance(number, str) and number and not any(c.isspace() for c in number), 'invalid shot number')
        require(number not in numbers, 'duplicate shot number')
        require(isinstance(node, str) and NODE.fullmatch(node), 'invalid nodeId')
        require(node not in ids, 'duplicate nodeId')
        numbers.add(number)
        ids.add(node)
        prefix = f'{drama}-{episode}-{number}'
        prompt = shot.get('prompt')
        require(isinstance(prompt, str) and '\n' in prompt and prompt.split('\n', 1)[0] == prefix, 'prompt must start with exact identifier line')
        require(prompt.split('\n', 1)[1].strip(), 'empty prompt body')
        title = shot.get('title', '')
        require(title == prefix or title.startswith(prefix + ' '), 'title identifier mismatch')
        refs = shot.get('refs', [])
        require(isinstance(refs, list) and all(isinstance(r, str) and r.startswith('node:') and NODE.fullmatch(r[5:]) for r in refs), 'refs must contain real-format node selectors')
        require(len(refs) == len(set(refs)), 'duplicate reference')
        require(set(REF.findall(prompt)).issubset(set(refs)), 'prompt reference missing from refs')
        require('node:' + node not in refs, 'self reference')
        duration = shot.get('duration')
        require(isinstance(duration, (int, float)) and not isinstance(duration, bool) and 0 < duration < float('inf'), 'invalid duration')
        require(not any(shot.get(k) not in (None, False) for k in ('run', 'wait', 'generate')), 'generation flags prohibited')
    return len(shots)

def self_test():
    import copy
    base = {'projectId': '11111111-1111-4111-8111-111111111111', 'projectConfirmed': True, 'drama': '测试', 'episode': '86', 'promptSource': {'mode': 'model'}, 'settings': {'ratio': '16:9', 'model': 'verified-model', 'resolution': '720p'}, 'generate': False, 'shots': [{'shot': '1-01', 'nodeId': 'node_0123456789', 'title': '测试-86-1-01 草稿', 'prompt': '测试-86-1-01\n{{node:node_abcdefghjk}}向前走。', 'duration': 8, 'refs': ['node:node_abcdefghjk']}]}
    assert validate(base) == 1
    cases = []
    p = copy.deepcopy(base); p['generate'] = True; cases.append(p)
    p = copy.deepcopy(base); p['shots'][0]['prompt'] = '错误前缀\n正文'; cases.append(p)
    p = copy.deepcopy(base); p['shots'][0]['refs'] = []; cases.append(p)
    p = copy.deepcopy(base); p['shots'].append(copy.deepcopy(p['shots'][0])); cases.append(p)
    p = copy.deepcopy(base); p['shots'][0]['run'] = True; cases.append(p)
    p = copy.deepcopy(base); p['promptSource'] = {'mode': 'invalid'}; cases.append(p)
    p = copy.deepcopy(base); p['settings']['ratio'] = '0:9'; cases.append(p)
    for p in cases:
        try:
            validate(p)
        except ValueError:
            continue
        raise AssertionError('invalid plan accepted')
    print('Self-test passed: 1 valid plan and 7 invalid plans; no server writes.')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan', nargs='?')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    try:
        if args.self_test:
            self_test()
        elif args.plan:
            count = validate(json.loads(Path(args.plan).read_text(encoding='utf-8-sig')))
            print(json.dumps({'valid': True, 'shots': count, 'generationAllowed': False}))
        else:
            parser.error('provide a plan path or --self-test')
    except (ValueError, OSError, TypeError, KeyError) as exc:
        print('Validation failed: ' + str(exc), file=sys.stderr)
        sys.exit(2)
